ATMEGA16 Fuses:
E:FF, H:9C, L:BF

SrNo.	Key	Pin	Port Pin
1	A	1	PB0
2	B	2	PB1
3	SW	3	PB2

Rotary Encoder
A (CLK) - PB0
B (DT)	- PB1
SW	- PB2 (MUTE)


Rotation Clockwise		Vol up
Rotation CounterClockwise	Vol down
Press				MUTE
